package Pruebas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Gestor_de_usuario {

    public static void Guardar(Persona persona) {
        try {
            FileOutputStream file = new FileOutputStream("src/Pruebas/Usuarios/" + persona.getNombre() + ".ser");
            ObjectOutputStream object = new ObjectOutputStream(file);
            object.writeObject(persona);
            object.close();
            file.close();
        } catch (IOException e) {
            System.out.println("No se ha podido guardar el usuario");
        }
    }

    public static Persona cargar(String nombre, String contrasena) {
        try {
            Persona devolver;
            FileInputStream fileIn = new FileInputStream("src/Pruebas/Usuarios/" + nombre + ".ser");
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            devolver = (Persona) objectIn.readObject();
            objectIn.close();
            fileIn.close();
            if (devolver.getContraseña().equals(contrasena)) {
                return devolver;
            } else {
                return null;
            }
        } catch (IOException e) {
            System.out.println("No se ha podido cargar el usuario");
            return null;
        } catch (ClassNotFoundException c) {
            System.out.println("No se ha podido encontrar el usuario");
            return null;
        }

    }

    public static void Eliminar(String nombre) throws ClassNotFoundException, FileNotFoundException, IOException {
        File borrar = new File("src/Pruebas/Usuarios/"+nombre + ".ser");
        if (borrar.delete()) {
            System.out.println(borrar.getName() + " is deleted!");
        } else {
            System.out.println("File is not deleted.");
        }
    }
}
