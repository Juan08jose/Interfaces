package Pruebas;

public class Usuario extends Persona{
    
    public boolean admin; 
    
    public Usuario(String nombre, String contraseña) {
        super(nombre, contraseña);
    }

    public boolean getAdmin() {
        return admin;
    }
}
