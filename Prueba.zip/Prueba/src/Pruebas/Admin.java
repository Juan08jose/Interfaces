package Pruebas;

public class Admin extends Persona {

    public boolean admin;

    public Admin(String nombre, String contraseña) {
        super(nombre, contraseña);
        admin = true;
    }

    public boolean getAdmin() {
        return admin;
    }
}
