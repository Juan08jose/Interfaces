/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexionDataBase;

import java.sql.*;

/**
 *
 * @author Juanm
 */
public class InteraccionDataBase {

    public static void main(String[] args) throws SQLException {
        Connection cn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Juanm\\Lectores.db");
        Statement st = cn.createStatement();
        String comando = "SELECT* FROM Manga";
        ResultSet rs = st.executeQuery(comando);
        while (rs.next()) {
            System.out.println(rs.getString(1) + " " + rs.getString("Nombre") + " " + rs.getString("Genero"));
        }

    }
}
